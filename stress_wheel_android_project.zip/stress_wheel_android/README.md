# Stress Wheel — Android Studio project

This project wraps the supplied offline HTML game in a native Android application.

## Project settings
- App name: Stress Wheel
- Package ID: `com.stresswheel.app` (change before first Play Store release if you want a different permanent ID)
- Minimum Android: Android 6.0 (API 23)
- Compile / target SDK: Android 16 (API 36)
- No internet permission; the game loads locally from the app's assets.
- Portrait orientation and immersive full-screen mode.

## Build an installable APK
1. Install the latest stable Android Studio.
2. Install Android SDK Platform 36 and Android SDK Build-Tools from SDK Manager.
3. Open this folder in Android Studio.
4. Wait for Gradle sync to finish.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the generated APK location. Install it on your Android phone and test it.

## Build the Play Store AAB
1. In Android Studio select **Build > Generate Signed Bundle / APK**.
2. Select **Android App Bundle**.
3. Create a new upload key/keystore and save it somewhere safe. Do not share it.
4. Choose the `release` build variant and finish.
5. Upload the generated `.aab` file to Google Play Console.

## Before publishing
- Choose your final package ID before publishing. After the first release, changing it means creating a different app listing.
- Create a Play Console developer account and complete identity verification.
- Prepare store icon, screenshots, short description, full description, content rating and Data safety answers.
- Test the app on real devices. Complete any testing track requirements shown in your Play Console account.
- This app currently has no ads, analytics, login, or network access. If you add any of those later, update the privacy disclosures and Data safety form accordingly.

## Important
This is the Android Studio source project, not a signed APK/AAB. A signed release bundle must be generated with your own upload key in Android Studio.
